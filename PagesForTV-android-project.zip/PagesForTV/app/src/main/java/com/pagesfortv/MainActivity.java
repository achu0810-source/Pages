package com.pagesfortv;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setBackgroundColor(0xFF111111);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
    }

    /** Lets the page make HTTPS requests without browser CORS limits. */
    class Bridge {
        @JavascriptInterface
        public void http(final String id, final String method, final String url,
                         final String headers, final String body) {
            new Thread(() -> {
                JSONObject out = new JSONObject();
                try {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(30000);
                    String m = method;
                    if (m.equals("PATCH")) { c.setRequestProperty("X-HTTP-Method-Override", "PATCH"); m = "POST"; }
                    c.setRequestMethod(m);
                    JSONObject h = new JSONObject(headers);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) { String k = it.next(); c.setRequestProperty(k, h.getString(k)); }
                    if (!m.equals("GET")) {
                        c.setDoOutput(true);
                        OutputStream o = c.getOutputStream();
                        if (body != null && body.length() > 0) o.write(body.getBytes("UTF-8"));
                        o.close();
                    }
                    int code = c.getResponseCode();
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    if (in != null) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close(); }
                    out.put("status", code).put("body", bo.toString("UTF-8"));
                } catch (Exception e) {
                    try { out.put("status", 0).put("body", String.valueOf(e)); } catch (Exception x) { }
                }
                final String js = "window.__cb('" + id + "'," + out.toString() + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK) {
            web.evaluateJavascript(
                "(function(){var o=document.getElementById('ov');if(o&&o.classList.contains('on')){document.getElementById('cx').click();return 1}var a=document.activeElement;if(a&&(a.id==='ed'||a.id==='title')){var d=document.querySelector('.doc.on');if(d){d.focus();return 1}}return 0})()",
                v -> { if (!"1".equals(v)) finish(); });
            return true;
        }
        return super.onKeyDown(code, e);
    }
}
