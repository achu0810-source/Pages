Pages for TV - Android/Google TV project

OPTION A (Android Studio): File > Open this folder, let it sync, then Build > Build APK(s).
  APK: app/build/outputs/apk/debug/app-debug.apk

OPTION B (no install, GitHub): create a free GitHub repo, upload this folder's contents,
  open Actions > Build APK > Run workflow, then download "PagesForTV-apk".

INSTALL ON MOTOROLA ENVISION (Google TV):
  1. Settings > System > About > tap the build number 7 times to enable Developer options.
  2. Developer options > turn on USB debugging (or network debugging).
  3. Find the TV's IP in network settings. On your computer:
       adb connect TV_IP:5555
       adb install app-debug.apk
  Or copy the APK to a USB drive, open it with a file manager app on the TV,
  and allow "Install unknown apps" for that app.
